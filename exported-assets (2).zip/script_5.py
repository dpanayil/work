# Create a streamlined, practical implementation
print("GAS TURBINE VIBRATION ANALYSIS - STREAMLINED VERSION")
print("="*60)

# Core implementation with essential components
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

class TurbineVibrationAnalyzer:
    """
    Streamlined analyzer for gas turbine vibration patterns
    """
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.feature_selector = None
        self.models = {}
        
    def load_sample_data(self):
        """Generate representative sample data"""
        np.random.seed(42)
        n_samples = 1000  # Smaller for demonstration
        n_features = 100   # Reduced feature count
        
        # Generate synthetic turbine parameters
        data = np.random.normal(0, 1, (n_samples, n_features))
        
        # Create realistic parameter names
        param_names = []
        for i in range(n_features):
            param_type = ['temp', 'press', 'flow', 'speed'][i % 4]
            location = ['inlet', 'outlet', 'stage1', 'stage2'][i % 4]
            param_names.append(f"{param_type}_{location}_{i}")
        
        # Create target with realistic patterns
        load_factor = np.random.uniform(0.2, 1.0, n_samples)
        part_load_mask = (load_factor > 0.4) & (load_factor < 0.8)
        
        axial_vibration = (
            1.0 +  # baseline
            3.0 * part_load_mask.astype(float) +  # part load spike
            0.5 * data[:, 0] +  # temperature effect
            0.3 * data[:, 10] +  # pressure effect
            np.random.normal(0, 0.3, n_samples)  # noise
        )
        
        df = pd.DataFrame(data, columns=param_names)
        df['axial_vibration'] = axial_vibration
        df['load_factor'] = load_factor
        
        return df
    
    def analyze_correlations(self, df, target='axial_vibration'):
        """Quick correlation analysis"""
        feature_cols = [col for col in df.columns if col not in [target, 'load_factor']]
        correlations = df[feature_cols + [target]].corr()[target].abs().sort_values(ascending=False)
        
        print("Top 10 correlations with axial vibration:")
        print(correlations.head(11))  # +1 for target itself
        
        return correlations
    
    def select_features(self, X, y, k=20):
        """Feature selection using statistical tests"""
        self.feature_selector = SelectKBest(score_func=f_regression, k=k)
        X_selected = self.feature_selector.fit_transform(X, y)
        
        selected_features = X.columns[self.feature_selector.get_support()]
        print(f"\nSelected {k} most important features:")
        print(list(selected_features))
        
        return X_selected, selected_features
    
    def train_models(self, X, y):
        """Train multiple models for pattern recognition"""
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Random Forest model
        rf_model = RandomForestRegressor(n_estimators=50, random_state=42)
        rf_model.fit(X_train_scaled, y_train)
        
        # Predictions
        y_pred = rf_model.predict(X_test_scaled)
        
        # Metrics
        mse = mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        self.models['random_forest'] = rf_model
        
        print(f"\nModel Performance:")
        print(f"R² Score: {r2:.3f}")
        print(f"RMSE: {np.sqrt(mse):.3f}")
        
        return y_test, y_pred
    
    def identify_vibration_patterns(self, df, threshold=3.0):
        """Identify conditions leading to high vibration"""
        high_vib_mask = df['axial_vibration'] > threshold
        
        print(f"\nHigh Vibration Analysis (>{threshold}):")
        print(f"Total high vibration samples: {high_vib_mask.sum()}")
        print(f"Percentage: {high_vib_mask.mean()*100:.1f}%")
        
        # Analyze load factor correlation
        high_vib_data = df[high_vib_mask]
        normal_data = df[~high_vib_mask]
        
        print(f"\nLoad Factor Analysis:")
        print(f"Average load during high vibration: {high_vib_data['load_factor'].mean():.3f}")
        print(f"Average load during normal operation: {normal_data['load_factor'].mean():.3f}")
        
        # Part load analysis
        part_load_high = ((high_vib_data['load_factor'] > 0.4) & 
                         (high_vib_data['load_factor'] < 0.8)).mean()
        part_load_normal = ((normal_data['load_factor'] > 0.4) & 
                           (normal_data['load_factor'] < 0.8)).mean()
        
        print(f"Part load operation during high vibration: {part_load_high*100:.1f}%")
        print(f"Part load operation during normal: {part_load_normal*100:.1f}%")
        
        return high_vib_mask

# Run the analysis
analyzer = TurbineVibrationAnalyzer()

print("\nStep 1: Loading Data")
print("-" * 30)
data = analyzer.load_sample_data()
print(f"Dataset shape: {data.shape}")

print("\nStep 2: Correlation Analysis")
print("-" * 30)
correlations = analyzer.analyze_correlations(data)

print("\nStep 3: Feature Selection")
print("-" * 30)
feature_cols = [col for col in data.columns if col not in ['axial_vibration', 'load_factor']]
X = data[feature_cols]
y = data['axial_vibration']

X_selected, selected_features = analyzer.select_features(X, y, k=20)

print("\nStep 4: Model Training")
print("-" * 30)
y_test, y_pred = analyzer.train_models(X_selected, y)

print("\nStep 5: Pattern Identification")
print("-" * 30)
high_vib_mask = analyzer.identify_vibration_patterns(data)

print("\n" + "="*60)
print("ANALYSIS COMPLETE!")
print("="*60)