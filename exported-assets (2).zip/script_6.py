# Simple, focused implementation for gas turbine vibration analysis
print("GAS TURBINE VIBRATION ANALYSIS TOOLKIT")
print("="*50)

# Essential imports
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.ensemble import RandomForestRegressor, IsolationForest
from sklearn.decomposition import PCA

# Create sample data quickly
np.random.seed(42)
n_samples, n_features = 500, 50  # Smaller for demo

# Generate sample turbine data
data = np.random.normal(0, 1, (n_samples, n_features))
param_names = [f"param_{i}" for i in range(n_features)]

# Create realistic vibration target
load_factor = np.random.uniform(0.2, 1.0, n_samples)
part_load_condition = (load_factor > 0.4) & (load_factor < 0.8)

vibration = (1.0 + 
            2.5 * part_load_condition.astype(float) + 
            0.4 * data[:, 0] + 
            0.2 * data[:, 5] + 
            np.random.normal(0, 0.2, n_samples))

df = pd.DataFrame(data, columns=param_names)
df['axial_vibration'] = vibration
df['load_factor'] = load_factor

print(f"✓ Created dataset: {df.shape}")
print(f"✓ High vibration samples (>3): {(df['axial_vibration'] > 3).sum()}")

# Quick analysis
print("\nTOP CORRELATIONS:")
feature_cols = [col for col in df.columns if col not in ['axial_vibration', 'load_factor']]
correlations = df[feature_cols + ['axial_vibration']].corr()['axial_vibration'].abs().sort_values(ascending=False)
print(correlations.head(6))

print("\nFEATURE SELECTION:")
X = df[feature_cols]
y = df['axial_vibration']

selector = SelectKBest(score_func=f_regression, k=10)
X_selected = selector.fit_transform(X, y)
selected_features = X.columns[selector.get_support()]
print(f"Selected features: {list(selected_features)}")

print("\nMODEL TRAINING:")
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_selected)

rf_model = RandomForestRegressor(n_estimators=20, random_state=42)
rf_model.fit(X_scaled, y)
r2_score = rf_model.score(X_scaled, y)
print(f"✓ Random Forest R² Score: {r2_score:.3f}")

print("\nANOMALY DETECTION:")
iso_forest = IsolationForest(contamination=0.1, random_state=42)
anomalies = iso_forest.fit_predict(X_scaled)
anomaly_count = (anomalies == -1).sum()
print(f"✓ Detected {anomaly_count} anomalies")

print("\nPATTERN ANALYSIS:")
high_vib = df['axial_vibration'] > 3
print(f"High vibration samples: {high_vib.sum()}")
print(f"Average load factor during high vibration: {df[high_vib]['load_factor'].mean():.3f}")
print(f"Part load correlation: {part_load_condition[high_vib].mean()*100:.1f}%")

print("\n✓ ANALYSIS COMPLETE - Code components ready for your implementation!")