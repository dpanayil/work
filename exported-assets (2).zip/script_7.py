# Minimal working example
import numpy as np
import pandas as pd

print("Gas Turbine Vibration Analysis - Basic Framework")
print("="*50)

# Create minimal sample data
np.random.seed(42)
n = 100  # Very small dataset
data = np.random.normal(0, 1, (n, 10))
vibration = np.random.normal(2, 1, n)

print(f"Sample data created: {n} samples, 10 features")
print(f"Vibration range: {vibration.min():.2f} to {vibration.max():.2f}")
print("✓ Framework ready for expansion")