# Part 1: Data Preprocessing and Feature Engineering Module
class TurbineDataProcessor:
    """
    Comprehensive data preprocessing class for gas turbine vibration analysis
    Handles large datasets with 1000+ parameters
    """
    
    def __init__(self):
        self.scaler = None
        self.feature_names = None
        self.vibration_threshold = None
        
    def load_and_validate_data(self, data_path=None, synthetic=True):
        """
        Load turbine data - using synthetic data for demonstration
        In practice, replace with your actual data loading
        """
        if synthetic:
            # Generate synthetic turbine data similar to real conditions
            np.random.seed(42)
            n_samples = 10000
            n_features = 1000
            
            # Create realistic turbine parameter names
            param_names = []
            categories = ['temp', 'press', 'flow', 'vib', 'speed', 'fuel', 'air', 'oil']
            locations = ['inlet', 'outlet', 'stage1', 'stage2', 'bearing1', 'bearing2']
            
            for i in range(n_features):
                cat = categories[i % len(categories)]
                loc = locations[i % len(locations)]
                param_names.append(f"{cat}_{loc}_{i}")
            
            # Generate correlated features with some noise
            data = np.random.normal(0, 1, (n_samples, n_features))
            
            # Add some correlations to make it more realistic
            for i in range(0, n_features, 10):
                if i+5 < n_features:
                    data[:, i+1:i+5] = data[:, i:i+1] + np.random.normal(0, 0.3, (n_samples, 4))
            
            # Create axial vibration target with some realistic patterns
            # Higher vibration during part load conditions (40-80% load)
            load_factor = np.random.uniform(0.2, 1.0, n_samples)
            part_load_mask = (load_factor > 0.4) & (load_factor < 0.8)
            
            axial_vibration = (
                0.5 + 
                2.0 * part_load_mask.astype(float) +  # Higher at part load
                0.3 * data[:, 0] +  # Temperature effect
                0.2 * data[:, 10] +  # Pressure effect
                0.1 * data[:, 50] +  # Speed effect
                np.random.normal(0, 0.2, n_samples)  # Noise
            )
            
            df = pd.DataFrame(data, columns=param_names)
            df['axial_vibration'] = axial_vibration
            df['load_factor'] = load_factor
            df['timestamp'] = pd.date_range('2023-01-01', periods=n_samples, freq='1min')
            
            print(f"✓ Generated synthetic dataset: {df.shape}")
            print(f"✓ Features: {n_features}, Samples: {n_samples}")
            
        else:
            # Load real data (placeholder)
            print("Loading real turbine data...")
            # df = pd.read_csv(data_path)
            
        return df
    
    def detect_anomalies_in_features(self, df, contamination=0.1):
        """
        Detect anomalous data points that might affect analysis
        """
        feature_cols = [col for col in df.columns if col not in ['axial_vibration', 'load_factor', 'timestamp']]
        
        # Use Isolation Forest for anomaly detection
        iso_forest = IsolationForest(contamination=contamination, random_state=42)
        anomalies = iso_forest.fit_predict(df[feature_cols])
        
        df['is_anomaly'] = (anomalies == -1)
        anomaly_count = df['is_anomaly'].sum()
        
        print(f"✓ Detected {anomaly_count} anomalous data points ({anomaly_count/len(df)*100:.2f}%)")
        
        return df
    
    def create_time_features(self, df):
        """
        Extract time-based features from timestamp
        """
        if 'timestamp' in df.columns:
            df['hour'] = df['timestamp'].dt.hour
            df['day_of_week'] = df['timestamp'].dt.dayofweek
            df['month'] = df['timestamp'].dt.month
            
            # Create cyclic features for better ML performance
            df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
            df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
            df['day_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
            df['day_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
            
            print("✓ Created time-based features")
        
        return df
    
    def create_rolling_features(self, df, windows=[5, 10, 30]):
        """
        Create rolling statistics for vibration analysis
        """
        vibration_col = 'axial_vibration'
        
        for window in windows:
            df[f'vib_rolling_mean_{window}'] = df[vibration_col].rolling(window=window).mean()
            df[f'vib_rolling_std_{window}'] = df[vibration_col].rolling(window=window).std()
            df[f'vib_rolling_max_{window}'] = df[vibration_col].rolling(window=window).max()
        
        # Create lag features
        for lag in [1, 2, 5, 10]:
            df[f'vib_lag_{lag}'] = df[vibration_col].shift(lag)
        
        # Drop NaN values created by rolling operations
        df = df.dropna()
        
        print(f"✓ Created rolling and lag features, remaining samples: {len(df)}")
        
        return df

# Initialize the processor
processor = TurbineDataProcessor()

# Load and preprocess the data
print("\n" + "="*60)
print("STEP 1: DATA LOADING AND PREPROCESSING")
print("="*60)

# Load synthetic turbine data
turbine_data = processor.load_and_validate_data()

# Display basic statistics
print(f"\nDataset Overview:")
print(f"Shape: {turbine_data.shape}")
print(f"Axial Vibration Stats:")
print(turbine_data['axial_vibration'].describe())

print(f"\nHigh Vibration Samples (>3.0): {(turbine_data['axial_vibration'] > 3.0).sum()}")
print(f"Percentage: {(turbine_data['axial_vibration'] > 3.0).mean()*100:.2f}%")