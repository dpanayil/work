# Continue with preprocessing and feature engineering
print("\n" + "="*60)
print("STEP 2: ADVANCED PREPROCESSING")
print("="*60)

# Apply preprocessing steps
turbine_data = processor.detect_anomalies_in_features(turbine_data)
turbine_data = processor.create_time_features(turbine_data)
turbine_data = processor.create_rolling_features(turbine_data)

print(f"Final dataset shape after preprocessing: {turbine_data.shape}")

# Part 2: Feature Selection and Dimensionality Reduction
class FeatureSelector:
    """
    Advanced feature selection for high-dimensional turbine data
    """
    
    def __init__(self):
        self.selected_features = None
        self.feature_importance = None
        self.pca_model = None
        
    def correlation_analysis(self, df, target_col='axial_vibration', threshold=0.1):
        """
        Identify features with high correlation to target
        """
        feature_cols = [col for col in df.columns 
                       if col not in [target_col, 'load_factor', 'timestamp', 'is_anomaly']]
        
        correlations = df[feature_cols + [target_col]].corr()[target_col].abs()
        high_corr_features = correlations[correlations > threshold].sort_values(ascending=False)
        
        print(f"✓ Found {len(high_corr_features)-1} features with correlation > {threshold}")
        print("Top 10 most correlated features:")
        print(high_corr_features.head(11))  # +1 for target itself
        
        return high_corr_features.index[1:].tolist()  # Exclude target itself
    
    def statistical_feature_selection(self, X, y, k=100):
        """
        Select features using statistical tests
        """
        # Use F-regression for continuous target
        selector = SelectKBest(score_func=f_regression, k=k)
        X_selected = selector.fit_transform(X, y)
        
        selected_features = X.columns[selector.get_support()].tolist()
        feature_scores = pd.DataFrame({
            'feature': X.columns,
            'score': selector.scores_,
            'selected': selector.get_support()
        }).sort_values('score', ascending=False)
        
        print(f"✓ Selected {k} features using statistical tests")
        print("Top 10 features by F-score:")
        print(feature_scores.head(10)[['feature', 'score']])
        
        return selected_features, feature_scores
    
    def recursive_feature_elimination(self, X, y, n_features=50):
        """
        Use RFE with Random Forest for feature selection
        """
        rf = RandomForestRegressor(n_estimators=100, random_state=42)
        rfe = RFE(estimator=rf, n_features_to_select=n_features)
        rfe.fit(X, y)
        
        selected_features = X.columns[rfe.support_].tolist()
        feature_ranking = pd.DataFrame({
            'feature': X.columns,
            'ranking': rfe.ranking_,
            'selected': rfe.support_
        }).sort_values('ranking')
        
        print(f"✓ RFE selected {n_features} features")
        print("Top 10 features by RFE ranking:")
        print(feature_ranking.head(10))
        
        return selected_features, feature_ranking
    
    def pca_analysis(self, X, n_components=0.95):
        """
        Apply PCA to reduce dimensionality
        """
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        pca = PCA(n_components=n_components)
        X_pca = pca.fit_transform(X_scaled)
        
        self.pca_model = pca
        
        explained_variance = pca.explained_variance_ratio_
        cumulative_variance = np.cumsum(explained_variance)
        
        print(f"✓ PCA reduced {X.shape[1]} features to {X_pca.shape[1]} components")
        print(f"✓ Explained variance: {cumulative_variance[-1]:.3f}")
        
        return X_pca, explained_variance, cumulative_variance

# Initialize feature selector
selector = FeatureSelector()

print("\n" + "Step 2.1: Feature Analysis")
print("-" * 40)

# Prepare features and target
feature_cols = [col for col in turbine_data.columns 
               if col not in ['axial_vibration', 'load_factor', 'timestamp', 'is_anomaly']]

X = turbine_data[feature_cols]
y = turbine_data['axial_vibration']

print(f"Feature matrix shape: {X.shape}")
print(f"Target vector shape: {y.shape}")

# Correlation analysis
high_corr_features = selector.correlation_analysis(turbine_data)

print(f"\nFound {len(high_corr_features)} highly correlated features")