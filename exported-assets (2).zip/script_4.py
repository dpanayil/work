# Continue with more efficient anomaly detection and pattern recognition
print("STEP 3: EFFICIENT ANOMALY DETECTION")
print("="*60)

# Simplified and faster anomaly detection
class FastVibrationDetector:
    """
    Fast anomaly detection for large turbine datasets
    """
    
    def __init__(self):
        self.models = {}
    
    def isolation_forest_fast(self, X, contamination=0.1):
        """Fast Isolation Forest implementation"""
        model = IsolationForest(
            contamination=contamination, 
            random_state=42,
            n_estimators=50  # Reduced for speed
        )
        anomaly_scores = model.fit_predict(X)
        anomalies = (anomaly_scores == -1)
        
        print(f"✓ Fast Isolation Forest: {anomalies.sum()} anomalies ({anomalies.mean()*100:.2f}%)")
        return anomalies
    
    def statistical_anomalies(self, y, threshold=2.5):
        """Statistical Z-score based detection"""
        z_scores = np.abs((y - y.mean()) / y.std())
        anomalies = z_scores > threshold
        
        print(f"✓ Statistical detection: {anomalies.sum()} anomalies ({anomalies.mean()*100:.2f}%)")
        return anomalies, z_scores

# Fast detection
detector = FastVibrationDetector()

# Select top features for faster processing
top_features = feature_scores.head(50)['feature'].tolist()
X_top = X[top_features]

print("Step 3.1: Fast Anomaly Detection")
print("-" * 40)

anomalies_fast = detector.isolation_forest_fast(X_top)
anomalies_stat, z_scores = detector.statistical_anomalies(y)

print("\n" + "="*60)
print("STEP 4: PATTERN RECOGNITION & ML MODELS")
print("="*60)

# Part 4: Machine Learning Models for Pattern Recognition
class TurbinePatternRecognizer:
    """
    Machine learning models to identify patterns causing vibration spikes
    """
    
    def __init__(self):
        self.models = {}
        self.results = {}
    
    def prepare_classification_data(self, X, y, threshold=3.0):
        """
        Convert regression to classification problem for spike detection
        """
        y_binary = (y > threshold).astype(int)
        print(f"✓ Created binary classification target:")
        print(f"  - Normal samples: {(y_binary == 0).sum()}")
        print(f"  - High vibration samples: {(y_binary == 1).sum()}")
        return y_binary
    
    def random_forest_analysis(self, X, y):
        """
        Random Forest for feature importance and pattern recognition
        """
        from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
        
        # Regression model
        rf_reg = RandomForestRegressor(n_estimators=100, random_state=42)
        rf_reg.fit(X, y)
        
        # Feature importance
        importance_df = pd.DataFrame({
            'feature': X.columns,
            'importance': rf_reg.feature_importances_
        }).sort_values('importance', ascending=False)
        
        # Classification model for spike detection
        y_binary = self.prepare_classification_data(X, y)
        rf_clf = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')
        rf_clf.fit(X, y_binary)
        
        self.models['random_forest'] = {'regressor': rf_reg, 'classifier': rf_clf}
        
        print(f"✓ Random Forest R² Score: {rf_reg.score(X, y):.3f}")
        print("✓ Top 10 most important features:")
        print(importance_df.head(10))
        
        return importance_df
    
    def gradient_boosting_analysis(self, X, y):
        """
        Gradient Boosting for advanced pattern recognition
        """
        from sklearn.ensemble import GradientBoostingRegressor
        
        gb_reg = GradientBoostingRegressor(n_estimators=100, random_state=42)
        gb_reg.fit(X, y)
        
        # Feature importance
        importance_df = pd.DataFrame({
            'feature': X.columns,
            'importance': gb_reg.feature_importances_
        }).sort_values('importance', ascending=False)
        
        self.models['gradient_boosting'] = gb_reg
        
        print(f"✓ Gradient Boosting R² Score: {gb_reg.score(X, y):.3f}")
        print("✓ Top 10 most important features:")
        print(importance_df.head(10))
        
        return importance_df

# Initialize pattern recognizer
recognizer = TurbinePatternRecognizer()

print("Step 4.1: Random Forest Analysis")
print("-" * 40)

# Use top selected features
rf_importance = recognizer.random_forest_analysis(X_top, y)

print("\nStep 4.2: Gradient Boosting Analysis")
print("-" * 40)

gb_importance = recognizer.gradient_boosting_analysis(X_top, y)