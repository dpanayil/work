# Continue with feature selection techniques
print("\nStep 2.2: Statistical Feature Selection")
print("-" * 40)

# Apply statistical feature selection
selected_features_stat, feature_scores = selector.statistical_feature_selection(X, y, k=100)

print("\nStep 2.3: Recursive Feature Elimination")
print("-" * 40)

# Apply RFE (using a subset for faster computation)
X_subset = X.iloc[:, :200]  # Use first 200 features for RFE demo
selected_features_rfe, feature_ranking = selector.recursive_feature_elimination(X_subset, y, n_features=20)

print("\nStep 2.4: PCA Analysis")
print("-" * 40)

# Apply PCA
X_pca, explained_variance, cumulative_variance = selector.pca_analysis(X, n_components=50)

print("\n" + "="*60)
print("STEP 3: ANOMALY DETECTION MODELS")
print("="*60)

# Part 3: Anomaly Detection Models
class VibrationAnomalyDetector:
    """
    Multiple anomaly detection approaches for vibration spikes
    """
    
    def __init__(self):
        self.models = {}
        self.results = {}
    
    def isolation_forest_detection(self, X, contamination=0.1):
        """
        Use Isolation Forest for anomaly detection
        """
        model = IsolationForest(contamination=contamination, random_state=42)
        anomaly_scores = model.fit_predict(X)
        anomaly_scores_prob = model.decision_function(X)
        
        self.models['isolation_forest'] = model
        
        anomalies = (anomaly_scores == -1)
        print(f"✓ Isolation Forest detected {anomalies.sum()} anomalies ({anomalies.mean()*100:.2f}%)")
        
        return anomalies, anomaly_scores_prob
    
    def autoencoder_detection(self, X, encoding_dim=50, threshold_percentile=95):
        """
        Use Autoencoder for anomaly detection
        """
        from sklearn.neural_network import MLPRegressor
        
        # Simple autoencoder using MLPRegressor
        # In practice, use TensorFlow/Keras for better autoencoders
        autoencoder = MLPRegressor(
            hidden_layer_sizes=(encoding_dim, X.shape[1]),
            max_iter=100,
            random_state=42,
            early_stopping=True,
            validation_fraction=0.1
        )
        
        # Normalize data
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Train autoencoder
        autoencoder.fit(X_scaled, X_scaled)
        
        # Calculate reconstruction error
        X_reconstructed = autoencoder.predict(X_scaled)
        reconstruction_error = np.mean(np.square(X_scaled - X_reconstructed), axis=1)
        
        # Set threshold based on percentile
        threshold = np.percentile(reconstruction_error, threshold_percentile)
        anomalies = reconstruction_error > threshold
        
        self.models['autoencoder'] = {'model': autoencoder, 'scaler': scaler, 'threshold': threshold}
        
        print(f"✓ Autoencoder detected {anomalies.sum()} anomalies ({anomalies.mean()*100:.2f}%)")
        print(f"✓ Reconstruction error threshold: {threshold:.4f}")
        
        return anomalies, reconstruction_error
    
    def statistical_detection(self, y, z_threshold=2.5):
        """
        Statistical anomaly detection based on Z-score
        """
        z_scores = np.abs((y - y.mean()) / y.std())
        anomalies = z_scores > z_threshold
        
        print(f"✓ Statistical method detected {anomalies.sum()} anomalies ({anomalies.mean()*100:.2f}%)")
        print(f"✓ Using Z-score threshold: {z_threshold}")
        
        return anomalies, z_scores

# Initialize anomaly detector
detector = VibrationAnomalyDetector()

print("\nStep 3.1: Isolation Forest Anomaly Detection")
print("-" * 50)

# Use selected features for anomaly detection
X_selected = X[selected_features_stat]
anomalies_iso, scores_iso = detector.isolation_forest_detection(X_selected)

print("\nStep 3.2: Autoencoder Anomaly Detection")
print("-" * 50)

# Use PCA features for autoencoder
anomalies_ae, reconstruction_errors = detector.autoencoder_detection(X_pca)

print("\nStep 3.3: Statistical Anomaly Detection")
print("-" * 50)

# Statistical detection on vibration values
anomalies_stat, z_scores = detector.statistical_detection(y)

# Combine results
combined_anomalies = anomalies_iso | anomalies_ae | anomalies_stat
print(f"\n✓ Combined approach detected {combined_anomalies.sum()} total anomalies")
print(f"✓ Percentage of data identified as anomalous: {combined_anomalies.mean()*100:.2f}%")